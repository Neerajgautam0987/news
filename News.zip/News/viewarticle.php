<?php
include("config.php"); 


$query = "SELECT * FROM `articles`";
$result = mysqli_query($connect, $query);
$articles = mysqli_fetch_all($result, MYSQLI_ASSOC);


foreach ($articles as $article) {
    echo "<h2>{$article['content']}</h2>";
    echo "<p>Author: {$article['author']}</p>";
    echo "<p>Category: {$article['category']}</p>";
    echo "<p>{$article['description']}</p>";
    echo "<img src='images/{$article['thumbnail']}' alt='Article Thumbnail' width='200'><br><br>";
}
?>
