<?php 
include ("viewart.php");
include ("");
?>