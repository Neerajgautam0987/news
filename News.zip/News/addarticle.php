<?php
include("admin_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('adlogin.php?msg=Login Yourself!!')</script>";

}
?>
    <div class="container my-5">
    <?php
        if(isset($_GET['msg']))
        {
        ?>
        <div class="alert alert-success" role="alert">
        
        <?php echo $_GET['msg']?>
        </div>
        <?php 
         }
        ?>
        <h1 class="text-center">Add Article</h1>
        
        <div class="row my-3">
            <div class="col-md-9 offset-md-2">
                <div class="card box p-3 mb-5   ">
                    <form enctype="multipart/form-data" method="post">
                    <div class="row">
                            <div class="col-md-3">
                                <label>Content</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="content"/>
                            </div>
                        </div>
                        <div class="row my-2">
                            <div class="col-md-3">
                                <label>Author</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="author"/>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-3">
                                <label>Category Name</label>
                            </div>
                            <div class="col-md-9">
                                <select class="form-control" name="category">
                                <?php
                                include("config.php");
                                $query="Select * from `add_category`";
                                $result=mysqli_query($connect,$query);
                                while($data=mysqli_fetch_array($result)){
                                    ?>
                                <option><?php echo $data['name']?></option>
                                <?php   
                                }
                                ?>
                            </select>
                        </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Description</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="description"/>
                            </div>
                        </div>
                        <div class="row my-3">
                            <div class="col-md-3">
                                <label>Thumbnail</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="file" name="art_img"/>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center">
                            <button class="btn btn-danger w-50" name="btn1">ADD</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
    <?php
    include("footer.php");
    ?>
<?php
    if(isset($_POST['btn1']))
    {
        // echo "Form has submitted";
        $content_name=$_POST['content'];

        $author_name=$_POST['author'];

        $category_name=$_POST['cat_name'];
        
        $descriptions=$_POST['description'];
        $image_name=$_FILES['art_img']['name'];
        $tmp_path=$_FILES['art_img']['tmp_name'];
        $new_name=rand().$image_name;
        // echo $new_name;
     

        include("config.php");
         $query="INSERT INTO `articles`(`content`,`author`,`category`,`description`,`thumbnail`) VALUES ('$content_name','$author_name',' $category_name','$descriptions','$new_name')";
       

         $result=mysqli_query($connect,$query);
         if($result>0){
            move_uploaded_file($tmp_path,"images/".$new_name);
            echo "<script>window.location.assign('addarticle.php?msg=Added Successfully')</script>";
         }
         else{
            echo "<script>window.location.assign('add_article.php?msg=Error while uploading')</script>";
         }
    }

?>
