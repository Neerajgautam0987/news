<!-- Your form has been submitted!!! -->
<?php
    // echo $_POST['email1'];
    // echo $_REQUEST['password'];
    if(isset($_POST['btn'])){
        $y=$_POST['email1'];
        $z=md5($_POST['password1']);
        include("config.php");
        $query="SELECT * from `admin_login` where `email`='$y' and `password`='$z' ";
         echo $query;
        $result=mysqli_query($connect,$query);
        // print_r($result);
        if(mysqli_num_rows($result)>0){
            session_start(); //start
            $_SESSION['email']=$y;  //create  
            $_SESSION['user_type']="Admin";
            echo "<script>window.location.assign('adminindex.php?msg=Login Successfully!!')</script>";
        }
        else{
            // echo "invalid";
            echo "<script>window.location.assign('adlogin.php')</script>";
        } 
    }
    
?>