<?php
include_once("loginheader.php");
session_start();

?>

<div class="container my-5">
    <h1 class="text-center">Admin Login</h1>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
                <form action="submit.php" method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>Email</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="email" name="email1"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Password</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="password" name="password1"/>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-warning w-25" name="btn">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>

<?php
include_once("footer.php");
?>