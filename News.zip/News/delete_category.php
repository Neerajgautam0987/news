<?php
$id=$_REQUEST['id'];
// echo $id;
include("config.php");
$query="DELETE from `add_category` where `id`='$id'";
$result=mysqli_query($connect,$query);
if($result>0)
{
    echo "<script>window.location.assign('catview.php?msg=Deleted Successfully')</script>";
}
else{
    echo "<script>window.location.assign('catview.php?msg=Error While deleting')</script>";
}
?>