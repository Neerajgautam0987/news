<?php
session_start();
session_unset();
echo "<script>window.location.assign('adlogin.php?msg=Logout Successfully!!')</script>";
?>