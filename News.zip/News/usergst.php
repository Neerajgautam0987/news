<?php
include_once("header.php");
?>

<div class="container my-5">
    <h1 class="text-center">User Register</h1>
    <?php
    if(isset($_GET['msg'])){
     echo $_GET['msg'];
    }
    ?>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
                <form  method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>User Name</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="user_name"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Email</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="email" name="email1"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Password</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="password" name="password"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Contact</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="number" name="contact"/>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-danger w-30" name="btn1">Register</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php
include_once("footer.php");
?>
<?php
    if(isset($_POST['btn1'])){
        $name=$_POST['user_name'];
        // echo $name;
        $email=$_POST['email1'];
        // echo $email;
        $contact=$_POST['contact'];
        // echo $contact;
        $password=md5($_POST['password']);
        // echo $password;
        include("config.php");
        $query="INSERT into `user_registration`(`name`,`email`,`password`,`contact`)VALUES('$name','$email','$password','$contact')";
        // echo $query;
        $result=mysqli_query($connect,$query);
        if($result>0){
            echo "<script>window.location.assign('userlogin.php?msg=Login Successfully!!!')</script>";
        }
        else{
            echo "<script>window.location.assign('usergst.php?msg=Error while adding')</script>";
        }
    }
?>