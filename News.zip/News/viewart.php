<?php
include("admin_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('adlogin.php?msg=Login Yourself!!')</script>";

}
?>
<div class="container table-responsive my-5">
    <?php
    if(isset($_REQUEST['msg'])){
    echo $_REQUEST['msg'];
    }
    ?>
     
     <div class="container my-2">
        <h1 class="text-center">Manage Article</h1>


    <table class="table table-bordered ">
        <tr>
            <th>Sr-No.</th>
            <th>Content</th>
            <th>Author</th>
            <th>Category</th>
            <th>Description</th>
            <th>Thumbnail</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php
        include("config.php");
        // $query="Select * from `category` where `id`='4'";
        // $query="Select category_name from `category` where `id`='4'";
        $query="Select * from `articles` ";
        // $query="Select thumbnail from `category` where `id`='4'";
        $result=mysqli_query($connect,$query);
        // print_r($result);
        $sno=1;
        while($data=mysqli_fetch_array($result))
        {
            // print_r($data);
            // echo "<tr>
            //     <td>".$data['category_name']."</td>
            // </tr>";
            ?>
            <tr>
                <td><?php echo $sno;?></td>
                <td><?php echo $data['content']?></td>
                <td><?php echo $data['author']?></td>
                <td><?php echo $data['category']?></td> 
                <td><?php echo $data['description']?></td>
                <td >
                    <img src="images/<?php echo $data['thumbnail']?>" style="height:150px; width:200px;">
                </td>
                <td>
                    <a href="editarticle.php?id=<?php echo  $data['id']?>" class="btn btn-info">Edit
                    </a>
                </td>
                <td>
                    <a href="delete_article.php?id=<?php echo $data['id']?>" class="btn btn-danger">Delete</a>
                </td>
            </tr>
        <?php   
        $sno++; 
        }
        ?>
    </table>
</div>
<?php
include("footer.php");
?>