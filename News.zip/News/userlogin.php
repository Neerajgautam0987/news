<?php
include("header.php");
?>

<div class="container my-5">
    <h1 class="text-center">User Login</h1>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
                <form method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>Email</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="email" name="email1"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Password</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="password" name="password"/>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-danger w-40" name="btn" >Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>





<?php
include("footer.php");
?>

<!-- Your form has been submitted!!! -->
<?php
    if(isset($_POST['btn'])){
        $y=$_POST['email1'];
        $z=md5($_POST['password']);
        include("config.php");
        $query="SELECT * from `user_registration` where `email`='$y' and `password`='$z' ";
         echo $query;
        $result=mysqli_query($connect,$query);
        // print_r($result);
        if(mysqli_num_rows($result)>0){
            session_start(); //start
            $_SESSION['user_email']=$y;  //create  
            $_SESSION['user_type']="user";
            echo "<script>window.location.assign('index.php?msg=Login Successfully!!')</script>";
        }
        else{
            // echo "invalid";
            echo "<script>window.location.assign('userlogin.php')</script>";
        } 
    }
    
?>