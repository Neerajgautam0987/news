<?php
include_once("user_header.php");


?>

<div class="container my-5">
    <h1 class="text-center">User Login</h1>
    <?php
    if(isset($_GET['msg'])){
     echo $_GET['msg'];
    }
    ?>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
                <form  method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>User Name</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="user_name"/>
                        </div>
                    </div>

                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Contact</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="number" name="contact"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Email</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="email" name="email1"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Password</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="password" name="password"/>
                        </div>
                    </div>
                 

                    
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-danger w-45" name="btn1">login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php
include_once("footer.php");
?>
<?php
    if(isset($_POST['btn1'])){

          
        $name=$_POST['user_name'];
       // echo $name;

       // echo $contact;
        $contact=$_POST['contact'];
   
        $email=$_POST['email1'];
        // echo $email;
       
       
        $password=md5($_POST['password']);
        // echo $password;
        
        include("config.php");
        $query="INSERT into user_registration (`name`,`contact`,`email`,`password`)VALUES('$name','$contact','$email','$password')";
        // echo $query;
        $result=mysqli_query($connect,$query);
    }
?>