<?php
include("admin_header.php");
?>
<div class="container table-responsive my-5">
    <?php
    if(isset($_REQUEST['msg'])){
    echo $_REQUEST['msg'];
    }
    ?>
     
     <div class="container my-2">
        <h1 class="text-center">User View</h1>


    <table class="table table-bordered ">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Email</th>
          
            <!-- <th>Password</th> -->
           
           
        </tr>
        <?php
        include("config.php");
        // $query="Select * from `category` where `id`='4'";
        // $query="Select category_name from `category` where `id`='4'";
        $query="SELECT * from `user_registration` ";
        // $query="Select thumbnail from `category` where `id`='4'";
        $result=mysqli_query($connect,$query);
        // print_r($result);
        $sno=1;
        while($data=mysqli_fetch_array($result))
        {
            // print_r($data);
            // echo "<tr>
            //     <td>".$data['category_name']."</td>
            // </tr>";
            ?>
            <tr>
                <td><?php echo $sno;?></td>
                <td><?php echo $data['name']?></td>
                <td><?php echo $data['contact']?></td>
                <td><?php echo $data['email']?></td>
           <!--  <?php echo $data['password']?> -->
               
            </tr>
        <?php   
        $sno++; 
        }
        ?>
    </table>
</div>
<?php
include("footer.php");
?>