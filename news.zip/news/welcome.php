<?php
include("header.php");
?>

<div class="row">
                        <div class="col-md-3">
                <p>WELCOME</p>
                        </div>


<?php
include("footer.php");
?>
