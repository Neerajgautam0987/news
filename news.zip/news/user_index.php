<?php
include("user_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('usergst.php?msg=Login Yourself!!')</script>";

}
?>

<?php
include("footer.php");
?>