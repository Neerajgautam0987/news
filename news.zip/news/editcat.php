<?php
include("admin_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('adlogin.php?msg=Login Yourself!!')</script>";

}
if(isset($_GET['id'])){
    $id=$_GET['id'];
    include("config.php");
    $query="SELECT * from `add_category` where `id`='$id'";
    $result=mysqli_query($connect,$query);
    $data=mysqli_fetch_array($result);
    // print_r($data);
}
?>
<div class="container my-5">
    <h1 class="text-center">Update Category</h1>
    <?php
    if(isset($_GET['msg'])){
    echo $_GET['msg'];
    }
    ?>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
                <form enctype="multipart/form-data"  method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>Category Name</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="cat_name" value="<?php echo $data['name']?>"/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Thumbnail</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="file" name="cat_img"/>
                            <input type="hidden"  name="hidden_img" value="<?php echo $data['thumbnail']?>">
                        </div>
                    </div>


                    
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-danger w-50" name="btn1">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php
if(isset($_POST['btn1'])){
    $category_name=$_POST['cat_name'];
    // echo $category_name;
    if($_FILES['cat_img']['name']){
        $img_name=$_FILES['cat_img']['name'];
        $img_path=$_FILES['cat_img']['tmp_name'];
        // echo $img_name, $img_path;
        $new_name=rand().$img_name;
        // echo $new_name;
        move_uploaded_file($img_path,"images/".$new_name);

    }
    else{
        $new_name=$_POST['hidden_img'];
        // echo $new_name;
    }
    include("config.php");
    $query="UPDATE `add_category` set `name`='$category_name',`thumbnail`='$new_name' where `id`='$id'";
    $result=mysqli_query($connect,$query);
    if($result>0){
        echo "<script>window.location.assign('catview.php?msg=Updated successfully!!')</script>";
    }
    else{
        echo "<script>window.location.assign('catview.php?msg=Error While updating data!!')</script>";
    }
}
?>
<?php
include("footer.php");
?>