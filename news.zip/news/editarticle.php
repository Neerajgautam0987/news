<?php
include("admin_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('adlogin.php?msg=Login Yourself!!')</script>";

}
if(isset($_GET['id'])){
    $id=$_GET['id'];
    
    // echo $id;
    include("config.php");
    $query="SELECT * from `articles` where `id`='$id'";
    // echo $query;
    $result=mysqli_query($connect,$query);
    $data=mysqli_fetch_array($result);
    // print_r($data);
}
?>
<div class="container my-5">
    <h1 class="text-center">Edit Article</h1>
    <?php
    if(isset($_GET['msg'])){
    echo $_GET['msg'];
    }
    ?>
    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3">
            <form enctype="multipart/form-data" method="post">
                    <div class="row">
                            <div class="col-md-3">
                                <label>Content</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="content" value="<?php echo $data['content']?>"/>
                            </div>
                        </div>

                        <div class="row my-2">
                        <div class="col-md-3">
                                <label>Title</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="title" value="<?php echo $data['Title']?>"/>
                            </div>
</div>

                        <div class="row my-2">
                            <div class="col-md-3">
                                <label>Author</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="author" value="<?php echo $data['author']?>"/>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-3">
                                <label>Category Name</label>
                            </div>
                            <div class="col-md-9">
                                <select class="form-control" name="category" value="<?php echo $data['category']?>">
                                <?php
                                include("config.php");
                                $query1="Select * from `add_category`";
                                $result1=mysqli_query($connect,$query1);
                                while($data1=mysqli_fetch_array($result1)){
                                    ?>
                                <option><?php echo $data1['name']?></option>
                                <?php   
                                }
                                ?>
                            </select>
                        </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Description</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="text" name="description" value="<?php  echo $data['description']?>"/>
                            </div>
                        </div>
                        <div class="row my-3">
                            <div class="col-md-3">
                                <label>Thumbnail</label>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" type="file" name="art_img" />
                                <input class="form-control" type="hidden" name="hidden_img" value="<?php echo $data['thumbnail']?>"/>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center">
                            <button class="btn btn-danger w-50" name="btn1">EDIT</button>
                        </div>
                    </form>
            </div>
        </div>
    </div>
    
</div>
<?php
if(isset($_POST['btn1'])){

    $content_name=$_POST['content'];

    $author_name=$_POST['author'];

    $category_name=$_POST['category'];

    $description_name=$_POST['description'];

    

    
    
    // echo $category_name;
    if($_FILES['art_img']['name']){
        $img_name=$_FILES['art_img']['name'];
        $img_path=$_FILES['art_img']['tmp_name'];
        // echo $img_name, $img_path;
        $new_name=rand().$img_name;
        // echo $new_name;
        move_uploaded_file($img_path,"images/".$new_name);

    }
    else{
        $new_name=$_POST['hidden_img'];
        // echo $new_name;
    }
    include("config.php");
    $query="UPDATE `articles` set  `content`='$content_name',  `author`='$author_name',`description`='$description_name',`thumbnail`='$new_name', `category`='$category_name' where `id`='$id'";
    echo $query;
    $result=mysqli_query($connect,$query);
    if($result>0){
        echo "<script>window.location.assign('viewart.php?msg=Updated successfully!!')</script>";
    }
    else{
        echo "<script>window.location.assign('viewart.php?msg=Error While updating data!!')</script>";
    }
}
?>
<?php
include("footer.php");
?>