<?php
include("admin_header.php");
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('adlogin.php?msg=Login Yourself!!')</script>";

}
?>


<?php
include("footer.php");
?>