<?php
$connect=mysqli_connect("localhost","root","","news_db");
?>