<?php
include("header.php");
?>
<div class="container">
    <div class="row">
        <?php
        include("config.php");
        $query="Select * from `articles`";
        $result=mysqli_query($connect,$query);
        while($data=mysqli_fetch_array($result)){

       ?>
        <div class="col-md-4 p-5">
            <div class="card" style="width: 18rem;">
            <img src="images/<?php echo $data['thumbnail']?>" class="card-img-top" alt="..." style="height:200px;">
            <div class="card-body">
                <h5 class="card-title"><?php echo $data['Title']?></h5>
              
                <a href="a.php" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
        <?php
         }
         ?>
    </div>
</div>
<?php
include("footer.php");
?>