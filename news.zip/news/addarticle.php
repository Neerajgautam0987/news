<?php
//session_start(); // Start the session
include("admin_header.php");


if (!isset($_SESSION['email'])) {
    header("Location: adlogin.php?msg=Login Yourself!!");
    exit(); // Add this line to stop executing further code
}

// Rest of the code remains the same...
?>
<div class="container my-5">
    <?php
    if (isset($_GET['msg'])) {
        ?>
        <div class="alert alert-success" role="alert">
            <?php echo $_GET['msg']; ?>
        </div>
        <?php
    }
    ?>
    <h1 class="text-center">Add Article</h1>

    <div class="row my-3">
        <div class="col-md-9 offset-md-2">
            <div class="card box p-3 mb-5">
                <form enctype="multipart/form-data" method="post">
                    <div class="row">
                        <div class="col-md-3">
                            <label>Content</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="content" required/>
                        </div>
                    </div>
                    <div class="row my-2">
                        <div class="col-md-3">
                            <label>Title</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="title" required/>
                        </div>
                    </div>
                    <div class="row my-2">
                        <div class="col-md-3">
                            <label>Author</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="author" required/>
                        </div>
                    </div>

                    <div class="row my-2">
                        <div class="col-md-3">
                            <label>Category Name</label>
                        </div>
                        <div class="col-md-9">
                            <select class="form-control" name="category" required>
                                <?php
                                include("config.php");
                                $query = "SELECT * FROM add_category";
                                $result = mysqli_query($connect, $query);
                                while ($data = mysqli_fetch_array($result)) {
                                    ?>
                                    <option><?php echo $data['name']; ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <label>Description</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="text" name="description" required/>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-md-3">
                            <label>Thumbnail</label>
                        </div>
                        <div class="col-md-9">
                            <input class="form-control" type="file" name="art_img" required/>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-danger w-50" type="submit" name="btn1">ADD</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
include("footer.php");

if (isset($_POST['btn1'])) {
    $content_name = $_POST['content'];
    $title_name = $_POST['title'];
    $author_name = $_POST['author'];
    $category_name = $_POST['category'];
    $descriptions = $_POST['description'];
    $image_name = $_FILES['art_img']['name'];
    $tmp_path = $_FILES['art_img']['tmp_name'];
    $new_name = uniqid() . '_' . $image_name;

    include("config.php");
    $query = "INSERT INTO articles (content, Title, author, category, description, thumbnail) VALUES ('$content_name', '$title_name', '$author_name', '$category_name', '$descriptions', '$new_name')";

    $result=mysqli_query($connect,$query);
    if($result>0){
       move_uploaded_file($tmp_path,"images/".$new_name);
       echo "<script>window.location.assign('addarticle.php?msg=Added Successfully')</script>";
    }
    else{
       echo "<script>window.location.assign('add_article.php?msg=Error while uploading')</script>";
    }
}
?>
