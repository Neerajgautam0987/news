<?php
session_start();
session_unset();
echo "<script>window.location.assign('usergst.php?msg=Logout Successfully!!')</script>";
?>